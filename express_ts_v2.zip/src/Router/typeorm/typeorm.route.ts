import { Router } from 'express';
import * as express from 'express';
import { User } from '../../entity/User';
import * as typeorm from 'typeorm';

//router 인스턴스를 하나 만들고
const router = Router();

let mysql1: typeorm.Connection;
let imgUpload = require('../../multer/imageUpload');

function getTypeormMysqlInstance(
  req: express.Request,
  res: express.Response,
  next: express.NextFunction,
) {
  mysql1 = req.app.get('mysql1');
  next();
}
router.use(getTypeormMysqlInstance);

router.get('/', function (요청, 응답) {
  응답.status(200).send('this router works');
});
router.post('/users', async (req, res) => {
  const userRepository = await mysql1.getRepository(User);
  console.log(req.body);
  const user = await userRepository.create({
    firstName: 'test',
    lastName: 'test',
  });
  const results = await userRepository.save(user);
  return res.send(results);
});

// 등록된 라우터를 export
export default router;
